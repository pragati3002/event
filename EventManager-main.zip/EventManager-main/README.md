**Description**

Orgatization often struggle to organize and mangae event efficentily. This is a web base event management dash bord to stream line the process of creating event,assigning task and tracking progress.

**Features**

1.Manage events
2.manage attendees and assign them task
3.Track task releated to event with progress visualization


**How to run**

->npm init -y
->node index.html
->npm install mongoose ,dotenv,jsonwebtoken,express,zod,bcrypt
->npx http-server --cors
